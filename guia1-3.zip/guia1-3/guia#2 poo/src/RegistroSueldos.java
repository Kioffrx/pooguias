import javax.swing.JOptionPane;

public class RegistroSueldos {
    public static void main(String[] args) {
        // Solicitar el número de empleados
        int numEmpleados = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de empleados:"));

        // Validar que el número de empleados sea mayor a 0
        while (numEmpleados <= 0) {
            numEmpleados = Integer.parseInt(JOptionPane.showInputDialog("Error: El número de empleados debe ser mayor a 0.\nIngrese nuevamente:"));
        }

        double[] sueldos = new double[numEmpleados];

        // Ingresar los sueldos de cada empleado
        for (int i = 0; i < numEmpleados; i++) {
            double sueldo;
            do {
                String input = JOptionPane.showInputDialog("Ingrese el sueldo del empleado " + (i + 1) + ":");
                sueldo = Double.parseDouble(input);

                if (sueldo < 0) {
                    JOptionPane.showMessageDialog(null, "Error: No se permiten sueldos negativos. Ingrese un valor válido.");
                }
            } while (sueldo < 0); // Repetir hasta que el sueldo sea positivo

            sueldos[i] = sueldo;
        }

        // Mostrar los sueldos ingresados
        StringBuilder resultado = new StringBuilder("Sueldos ingresados:\n");
        for (int i = 0; i < numEmpleados; i++) {
            resultado.append("Empleado ").append(i + 1).append(": $").append(String.format("%.2f", sueldos[i])).append("\n");
        }

        JOptionPane.showMessageDialog(null, resultado.toString());
    }
}