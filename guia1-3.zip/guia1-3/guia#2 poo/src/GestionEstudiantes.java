import java.util.HashMap;
import javax.swing.JOptionPane;

public class GestionEstudiantes {
    public static void main(String[] args) {
        // Crear el HashMap para almacenar los estudiantes
        HashMap<String, String> estudiantes = new HashMap<>();
        boolean salir = false;

        // Bucle principal para el menú
        while (!salir) {
            // Mostrar el menú
            String menu = "Menú de opciones:\n" +
                    "1. Ingreso de estudiante\n" +
                    "2. Ver estudiante\n" +
                    "3. Buscar estudiante\n" +
                    "4. Salir";
            String opcion = JOptionPane.showInputDialog(menu);

            switch (opcion) {
                case "1":
                    // Ingreso de estudiante
                    String carnet = JOptionPane.showInputDialog("Ingrese el carnet del estudiante:");
                    String nombre = JOptionPane.showInputDialog("Ingrese el nombre del estudiante:");
                    estudiantes.put(carnet, nombre);
                    JOptionPane.showMessageDialog(null, "Estudiante ingresado correctamente.");
                    break;
                case "2":
                    // Ver todos los estudiantes
                    if (estudiantes.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No hay estudiantes registrados.");
                    } else {
                        StringBuilder listaEstudiantes = new StringBuilder("Lista de estudiantes:\n");
                        for (String key : estudiantes.keySet()) {
                            listaEstudiantes.append("Carnet: ").append(key)
                                    .append(" - Nombre: ").append(estudiantes.get(key))
                                    .append("\n");
                        }
                        JOptionPane.showMessageDialog(null, listaEstudiantes.toString());
                    }
                    break;
                case "3":
                    // Buscar estudiante por carnet
                    String carnetBuscar = JOptionPane.showInputDialog("Ingrese el carnet del estudiante a buscar:");
                    if (estudiantes.containsKey(carnetBuscar)) {
                        String nombreEstudiante = estudiantes.get(carnetBuscar);
                        JOptionPane.showMessageDialog(null, "Estudiante encontrado: " + nombreEstudiante);
                    } else {
                        JOptionPane.showMessageDialog(null, "Estudiante no encontrado.");
                    }
                    break;
                case "4":
                    // Salir
                    salir = true;
                    JOptionPane.showMessageDialog(null, "Gracias por usar la aplicación.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida, por favor seleccione una opción válida.");
            }
        }
    }
}