import javax.swing.JOptionPane;

public class EvaluacionAlumno {
    public static void main(String[] args) {
        // Solicitar la nota al usuario
        String input = JOptionPane.showInputDialog("Ingrese la nota del alumno:");

        // Validar que se ingresó un número
        if (input != null) {
            try {
                double nota = Double.parseDouble(input);

                // Evaluar la nota del alumno
                if (nota >= 7.0) {
                    JOptionPane.showMessageDialog(null, "¡Felicidades! Has aprobado la materia.");
                } else if (nota >= 6.50 && nota < 7.0) {
                    JOptionPane.showMessageDialog(null, "Tienes derecho a un examen de suficiencia.");
                } else {
                    JOptionPane.showMessageDialog(null, "Lo sentimos, has reprobado la materia.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Debes ingresar un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Operación cancelada.");
        }
    }
}

