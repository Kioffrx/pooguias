import javax.swing.JOptionPane;
import java.util.Random;

public class TiendaDescuentos {
    public static void main(String[] args) {
        // Pedir al usuario el monto de la compra
        String input = JOptionPane.showInputDialog("Ingrese el monto total de la compra:");
        double montoCompra = Double.parseDouble(input);

        // Definir los colores de las bolitas
        String[] colores = {"Roja", "Verde", "Blanca"};

        // Seleccionar un color aleatorio
        Random random = new Random();
        int indiceColor = random.nextInt(colores.length);
        String colorSeleccionado = colores[indiceColor];

        // Determinar el descuento
        double descuento = 0;
        switch (colorSeleccionado) {
            case "Roja":
                descuento = 0.10;
                break;
            case "Verde":
                descuento = 0.05;
                break;
            case "Blanca":
                descuento = 0.00;
                break;
        }

        // Calcular el monto final
        double montoDescuento = montoCompra * descuento;
        double montoFinal = montoCompra - montoDescuento;

        // Mostrar el resultado
        String mensaje = "Color de bolita: " + colorSeleccionado + "\n" +
                "Descuento aplicado: " + (descuento * 100) + "%\n" +
                "Monto a pagar: $" + String.format("%.2f", montoFinal);

        if (colorSeleccionado.equals("Blanca")) {
            mensaje += "\nGracias por participar.";
        }

        JOptionPane.showMessageDialog(null, mensaje);
    }
}