public class Alumno {
    private String nombre;
    private String apellido;
    public Alumno(String nombre, String apellido,String Alumno) {





    }

}
