import java.util.Scanner;

public class AprovacionAlumnos {
    public static void main(String[] args){

        System.out.println("Ingrese el nombre del alumno: ");

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese la nota de un alumno: ");
        double nota = sc.nextDouble();
    if(nota >= 7.0){
    System.out.println("El alumno aprovado es: "+nota);
        }    else if(nota >= 6.50 && nota < 6.99){
        System.out.println("El alumno tiene posibilidad de un examen de recuperacion es: "+nota);

    }
    else {
        System.out.println("El allumno no a aprovado,es: "+nota);
    }
    sc.close();
    }

}
