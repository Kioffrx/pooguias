import CalculadoraBasica.CalculadoraBasica;
import CalculadoraAvanzada.CalculadoraAvanzada;

public class Main {
    public static void main(String[] args) {
        // Instanciar calculadoras
        CalculadoraBasica cBasica = new CalculadoraBasica();
        CalculadoraAvanzada cAvanzada = new CalculadoraAvanzada();

        // Pruebas con la calculadora básica
        System.out.println("Suma: " + cBasica.suma(10, 5));
        System.out.println("Resta: " + cBasica.resta(10, 5));
        System.out.println("Multiplicación: " + cBasica.multiplicacion(10, 5));
        System.out.println("División: " + cBasica.division(10, 5));

        // Pruebas con la calculadora avanzada
        System.out.println("Potencia: " + cAvanzada.potencia(2, 3));
        System.out.println("Opuesto: " + cAvanzada.opuesto(7));
        System.out.println("Factorial: " + cAvanzada.factorial(4));
    }
}