package CalculadoraBasica;

public class CalculadoraBasica {

    // Método para sumar dos números
    public double suma(double a, double b) {
        return a + b;
    }

    // Método para restar dos números
    public double resta(double a, double b) {
        return a - b;
    }

    // Método para multiplicar dos números
    public double multiplicacion(double a, double b) {
        return a * b;
    }

    // Método para dividir dos números
    public double division(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("No se puede dividir entre 0");
        }
        return a / b;
    }
}
