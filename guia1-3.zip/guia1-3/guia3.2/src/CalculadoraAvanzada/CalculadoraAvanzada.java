package CalculadoraAvanzada;

public class CalculadoraAvanzada {

    // Método para calcular la potencia (a^b)
    public double potencia(double base, double exponente) {
        return Math.pow(base, exponente);
    }

    // Método para obtener el opuesto de un número
    public double opuesto(double numero) {
        return -numero;
    }

    // Método para calcular el factorial de un número
    public int factorial(int numero) {
        if (numero < 0) {
            throw new IllegalArgumentException("El factorial no está definido para números negativos.");
        }
        int resultado = 1;
        for (int i = 1; i <= numero; i++) {
            resultado *= i;
        }
        return resultado;
    }
}