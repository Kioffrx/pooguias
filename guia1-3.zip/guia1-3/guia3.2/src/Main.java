import CalculadoraBasica.CalculadoraBasica;
import CalculadoraAvanzada.CalculadoraAvanzada;
import javax.swing.JOptionPane;
public class Main {
    public static void main(String[] args) {
        CalculadoraBasica cbasica = new CalculadoraBasica();
        CalculadoraAvanzada cavanzada = new CalculadoraAvanzada();

        String opcion;

        do {
            opcion = JOptionPane.showInputDialog("""
                Seleccione una operación:
                1. Suma
                2. Resta
                3. Multiplicación
                4. División
                5. Potencia
                6. Opuesto
                7. Factorial
                8. Salir
                """);

            switch (opcion) {
                case "1":
                    double num1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el primer número:"));
                    double num2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el segundo número:"));
                    JOptionPane.showMessageDialog(null, "Resultado: " + cbasica.suma(num1, num2));
                    break;

                case "2":
                    num1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el primer número:"));
                    num2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el segundo número:"));
                    JOptionPane.showMessageDialog(null, "Resultado: " + cbasica.resta(num1, num2));
                    break;

                case "3":
                    num1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el primer número:"));
                    num2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el segundo número:"));
                    JOptionPane.showMessageDialog(null, "Resultado: " + cbasica.multiplicacion(num1, num2));
                    break;

                case "4":
                    num1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el dividendo:"));
                    num2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el divisor:"));
                    try {
                        JOptionPane.showMessageDialog(null, "Resultado: " + cbasica.division(num1, num2));
                    } catch (ArithmeticException e) {
                        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
                    }
                    break;

                case "5":
                    num1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la base:"));
                    num2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el exponente:"));
                    JOptionPane.showMessageDialog(null, "Resultado: " + cavanzada.potencia(num1, num2));
                    break;

                case "6":
                    num1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el número:"));
                    JOptionPane.showMessageDialog(null, "Opuesto: " + cavanzada.opuesto(num1));
                    break;

                case "7":
                    int num = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número entero positivo:"));
                    try {
                        JOptionPane.showMessageDialog(null, "Factorial: " + cavanzada.factorial(num));
                    } catch (IllegalArgumentException e) {
                        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
                    }
                    break;

                case "8":
                    JOptionPane.showMessageDialog(null, "Saliendo del programa...");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Intente de nuevo.");
            }
        } while (!opcion.equals("8"));
    }

}