public class RegistroAnimales {
    public static void main(String[] args) {
        Gallo gallo = new Gallo("Claudio", 2, "Granos", "Rojo");
        Perro perro = new Perro("Rex", 5, "Croquetas", "Negro");
        Gato gato = new Gato("Michi", 3, "Pescado", "Verde");
        Hamster hamster = new Hamster("Bobby", 1, "Semillas", 5);

        System.out.println("Datos de los animales registrados:");
        System.out.println("----------------------------");
        gallo.mostrarDatos();
        System.out.println("----------------------------");
        perro.mostrarDatos();
        System.out.println("----------------------------");
        gato.mostrarDatos();
        System.out.println("----------------------------");
        hamster.mostrarDatos();
    }
}
