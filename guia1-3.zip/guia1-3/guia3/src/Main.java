//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Estudiante estudiante1 = new Estudiante("Juan Pérez", 20, "20241001");

        // Ingresando las materias
        estudiante1.ingresarMaterias();

        // Mostrando la información del estudiante
        estudiante1.mostrarInformacion();

    }
}