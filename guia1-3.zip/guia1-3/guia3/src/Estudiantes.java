import java.util.Scanner;
import java.util.ArrayList;
// Clase Estudiante
class Estudiante {
    private String nombre;
    private int edad;
    private String carnet;
    private ArrayList<String> materias;

    // Constructor
    public Estudiante(String nombre, int edad, String carnet) {
        this.nombre = nombre;
        this.edad = edad;
        this.carnet = carnet;
        this.materias = new ArrayList<>();
    }

    // Método para ingresar 5 materias
    public void ingresarMaterias() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese 5 materias para el estudiante " + nombre + ":");
        for (int i = 0; i < 5; i++) {
            System.out.print("Materia " + (i + 1) + ": ");
            String materia = scanner.nextLine();
            materias.add(materia);
        }
    }

    // Método para mostrar la información del estudiante
    public void mostrarInformacion() {
        System.out.println("\nInformación del Estudiante:");
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Carnet: " + carnet);
        System.out.println("Materias inscritas:");
        for (String materia : materias) {
            System.out.println("- " + materia);
        }
    }
}
